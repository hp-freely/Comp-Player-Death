////
// Comp Player Death is configured in two locations:
//   1) The in-game Options tab allows you to configure the one item that you might want to change on the fly.
//   2) This prefs file allows you to configure all other items associated with the script.
////
	// display standard T2 death messages in the chat window?
CompPD.displayPlayerDeathMessageInCoreChatWindow = true; 

	// maximum length of time (in seconds) which player death information will be displayed in a given HUD
	// valid values: 1 through 99 (value in seconds)
CompPD.maximumTimeLengthForDisplayingPlayerDeath = 60; 


	// The color that will be displayed for the text associated with the player's death for a given line.
	// Each color value must be a valid hexcode color (without the # character).
	//
	// From testing, the most generally readable colors are: neon green, light blue, and off white.
	// The most visible color to see against the sky and all terrains is generally neon green. Green naturally makes sense to assign to your teammates.
	// Light blue and off white are terrible against snow terrain and a light sky. However, given that we don't care about our own deaths or about 
	// deaths in observer, we can assign those colors in that context.
	// So, we need to figure out what to do for enemy deaths. In general, I've found that a medium red or a neon orange works okay against *most*
	// background colors. Red thas the same issues.
	// I have defaulted this script to red, because that's most associated with enemies. However, I would suggest trying neon orange as well
	// to see if that works bettte for you.
	//
	// Final commnet: If you're going to display the killer name, then the killer name will always use the same color setup. For example, if a friendly
	// player dies then:
	// -- If the killer of the player is an enemy, then the killer name will be displayed in the "enemy" color.
	// -- If the player was teamkilled, then the killer name will be disaplyed in the "friendly" color.
	// -- If the player was killed by yourself, then the killer will be displayed in the "self" color.
CompPD.playerDeathFontColor["friendly"] = "11dd11"; // neon green
CompPD.playerDeathFontColor["enemy"] = "ff5c00"; // ff3f20 medium red; // ff5c00 neon orange
CompPD.playerDeathFontColor["neutral"] = "bfbbbb"; // off white
CompPD.playerDeathFontColor["self"] = "33bbdd"; // light blue


	// When a player dies, that death is associated with a damage type that caused that death.
	// Unfortunately, the damage types are uniquely managed within a numerical array, where there
	// is zero context between that number and the associated damage type. You just have to figure it out
	// and assign values, as shown below. The array was taken from FilterMsg, 1-to-1.
	//
	// It is recommended to use a value that is two characters in length so that it fits within the GUI. If
	// you use a value that greater than two characters, then you will need to reposition the text controls in the HUD lines.
	//
	// index = 0 is a catch-all for death scenarios. From testing, I have found the following applies for index 0:
	//   a) Switching to another team.
	//   b) Switching to observer
	//   c) A type of death message called "MsgLegitKill"
	//      -- I am unsure what conditions exist where a) a specific Death Type is not set (index = 0), and b)
	//         T2 returns a message type of "MsgLegitKill".
CompPD.deathCauseArr[0] = "DE";			// DE = "Death"
CompPD.deathCauseArr[1] = "BL";			// blaster
CompPD.deathCauseArr[2] = "PL";			// plasma
CompPD.deathCauseArr[3] = "CG";			// chaingun
CompPD.deathCauseArr[4] = "DS";			// disc
CompPD.deathCauseArr[5] = "GR";			// grenade (launcher, regular nade)
CompPD.deathCauseArr[6] = "LA";			// laser
CompPD.deathCauseArr[7] = "EL";			// elf
CompPD.deathCauseArr[8] = "MO";			// mortar
CompPD.deathCauseArr[9] = "MI";			// missile
CompPD.deathCauseArr[10] = "SL";			// shocklance
CompPD.deathCauseArr[11] = "MN";			// mine
CompPD.deathCauseArr[12] = "EX";			// nearby explosion
CompPD.deathCauseArr[13] = "RO";			// run over / impact
CompPD.deathCauseArr[14] = "FA";			// fell too hard
CompPD.deathCauseArr[15] = "TU";			// default turret (used?)
CompPD.deathCauseArr[16] = "PT";			// plasma turret
CompPD.deathCauseArr[17] = "AA";			// aa turret
CompPD.deathCauseArr[18] = "ET";			// elf turret
CompPD.deathCauseArr[19] = "MT";			// mortar turret
CompPD.deathCauseArr[20] = "MI";			// missile turret
CompPD.deathCauseArr[21] = "CT";			// clamp turret
CompPD.deathCauseArr[22] = "LT";			// spike turret
CompPD.deathCauseArr[23] = "ST";			// sentry turret
CompPD.deathCauseArr[24] = "OB";			// out of bounds
CompPD.deathCauseArr[25] = "LV";			// lava
CompPD.deathCauseArr[26] = "SH";			// shrike blaster
CompPD.deathCauseArr[27] = "BO";			// bomber plasma
CompPD.deathCauseArr[28] = "BO";			// bomber bomb
CompPD.deathCauseArr[29] = "TA";			// tank gun
CompPD.deathCauseArr[30] = "TA";			// tank mortar
CompPD.deathCauseArr[31] = "SA";			// satchel charge
CompPD.deathCauseArr[32] = "MI";			// mpb missile (used?)
CompPD.deathCauseArr[33] = "LI";			// lightning
CompPD.deathCauseArr[34] = "VS";			// vehicle spawn
CompPD.deathCauseArr[35] = "FF";			// forcefield
CompPD.deathCauseArr[36] = "VC";			// vehicle crash
CompPD.deathCauseArr[98] = "NX";			// camping near nexus
CompPD.deathCauseArr[99] = "KO";			// suicide
CompPD.deathCauseArr["minedisc"] = "MD"; 	// minedisc kill
CompPD.deathCauseArr["headshot"] = "HS";	// headshot

	// Team Rabbit 2
CompPD.deathCauseArr[200] = "OG";			// touched own goal
CompPD.deathCauseArr[201] = "GR";			// grid death
CompPD.deathCauseArr[203] = "HP";			// hot potato
CompPD.deathCauseArr[204] = "OB";			// out of bounds


// ------ Look and Feel Profiles ------------ //
/////
// There are a limited set of fonts supported by T2. These are located in the /fonts folder. Unfortunately,
// there are few fonts available to choose from, and I'm not sure you can generate fonts in the correct 
// format anymore. "Arial" and "Arial Bold" have the most options to play with.
//
// Given the above, from experimentation, I have found that there are two configurations that work best. 
// Profile 1: If you're comfortable having a background for your HUDs, then using the smaller font Univers_15 looks very sharp. 
// Unfortunately, a) T2 doesn't provide a large font size for this font, and b) the font is hard to see without a background on your HUD.
//
// Profile 2: If you don't want a background for your HUD, then you need to use a larger font, like Arial_17. The font needs to be big enough
// so that you can see the text against the various terrains and sky textures.
//
// There is no dynamic way to apply a profile. However, I've basically set the settings for you below. Just uncomment the profile you want, and 
// comment the profile you don't want.
//
// In theory, you should be able to dynamically change the presentation of the HUD and data within that HUD through these variables only.
// Underscores were used in the variable name to keep things readable.
////

 
//   PROFILE 1: Small Font With Background
//   Recommended HUD Transparency: 0.2. This is set in the options UI in the in-game browser.

//	The maximum length of characters that will be displayed for a given player name in a line. If the max length
//	is reached, then the rest of the characters will be cut, and an elipses ("...") will replace them. (ex: "reallyLongName...")
//	if too many characters are in a given name, then that name will overflow down into the next line, which is annoying.
//	valid values: 5 through 20
//
//  I've found that max length of 12 is a good balance. It handles both short names and very long / wide names.
CompPD.playerNameMaxLength = 12;

//  maximum number of "wide" characters permitted in a player name. This impacts how a given player name is truncted in order
//  to fit within the parent HUD. I have found 6 to be a good number.
//  valid value 1 through 20
CompPD.playerNameMaxWideCharacters = 6;

//	 font family and size
CompPD.hudConfigArr["HUD_Line_Damage_Type_Font_Name"] = "Univers";
CompPD.hudConfigArr["HUD_Line_Damage_Type_Font_Size"] = 15;
CompPD.hudConfigArr["HUD_Line_Player_Name_Font_Name"] = "Univers";
CompPD.hudConfigArr["HUD_Line_Player_Name_Font_Size"] = 15;
CompPD.hudConfigArr["HUD_Line_Death_Time_Font_Name"] = "Univers";
CompPD.hudConfigArr["HUD_Line_Death_Time_Font_Size"] = 15;


// height of each line in a HUD
CompPD.hudConfigArr["HUD_Line_Height"] = 21;

// positioning of the Damage Type text
CompPD.hudConfigArr["HUD_Line_Damage_Type_X_Position"] = 5;
CompPD.hudConfigArr["HUD_Line_Damage_Type_Width"] = 30;
CompPD.hudConfigArr["HUD_Line_Damage_Type_Height"] = 20;
	
//	 positioning of the Time Since Death text
CompPD.hudConfigArr["HUD_Line_Death_Time_X_Position"] = 40;	
CompPD.hudConfigArr["HUD_Line_Death_Time_Width"] = 30;
CompPD.hudConfigArr["HUD_Line_Death_Time_Height"] = 20;
	
//	 positioning of the Player Name text
//   the player name X position varies depending on whether or not the death timer is configured to be displayed
CompPD.hudConfigArr["HUD_Line_Player_Name_X_Position_With_Death_Time"] = 80;
CompPD.hudConfigArr["HUD_Line_Player_Name_X_Position_Without_Death_Time"] = 40;

//   player width must equal no more than (HUD Width) - (Player Name X Position)
CompPD.hudConfigArr["HUD_Line_Player_Name_Width_Without_Killer_Name"] = 125;
CompPD.hudConfigArr["HUD_Line_Player_Name_Width_With_Killer_Name"] = 245;
CompPD.hudConfigArr["HUD_Line_Player_Name_Height"] = 20;

//	 parent HUD GUI width dependant on configuration variables
CompPD.hudConfigArr["HUD_Width_With_Death_Time_Without_Killer_Name"] = 205;
CompPD.hudConfigArr["HUD_Width_With_Death_Time_With_Killer_Name"] = 325;
CompPD.hudConfigArr["HUD_Width_Without_Death_Time_Without_Killer_Name"] = 165;
CompPD.hudConfigArr["HUD_Width_Without_Death_Time_With_Killer_Name"] = 285;



//    PROFILE 2: Large Font Without Background
//    Recommended HUD Transparency: 0.0. This is set in the options UI in the in-game browser.

//	The maximum length of characters that will be displayed for a given player name in a line. If the max length
//	is reached, then the rest of the characters will be cut, and an elipses ("...") will replace them. (ex: "reallyLongName...")
//	if too many characters are in a given name, then that name will overflow down into the next line, which is annoying.
//	valid values: 5 through 20
//
//  I've found that max length of 12 is a good balance. It handles both short names and very long / wide names.
// CompPD.playerNameMaxLength = 12;

//	maximum number of "wide" characters permitted in a player name. This impacts how a given player name is truncted in order
//	to fit within the parent HUD. I have found 6 to be a good number.
//  valid value 1 through 20
// CompPD.playerNameMaxWideCharacters = 6;

//	 font family and size/
// CompPD.hudConfigArr["HUD_Line_Damage_Type_Font_Name"] = "Arial";
// CompPD.hudConfigArr["HUD_Line_Damage_Type_Font_Size"] = 17;
// CompPD.hudConfigArr["HUD_Line_Player_Name_Font_Name"] = "Arial";
// CompPD.hudConfigArr["HUD_Line_Player_Name_Font_Size"] = 17;
// CompPD.hudConfigArr["HUD_Line_Death_Time_Font_Name"] = "Arial";
// CompPD.hudConfigArr["HUD_Line_Death_Time_Font_Size"] = 17;

//	 height of each line in a HUD
// CompPD.hudConfigArr["HUD_Line_Height"] = 21;

//	positioning of the Damage Type text
// CompPD.hudConfigArr["HUD_Line_Damage_Type_X_Position"] = 5;
// CompPD.hudConfigArr["HUD_Line_Damage_Type_Width"] = 30;
// CompPD.hudConfigArr["HUD_Line_Damage_Type_Height"] = 20;

//	 positioning of the Time Since Death text
// CompPD.hudConfigArr["HUD_Line_Death_Time_X_Position"] = 50;
// CompPD.hudConfigArr["HUD_Line_Death_Time_Width"] = 30;
// CompPD.hudConfigArr["HUD_Line_Death_Time_Height"] = 20;

//	 positioning of the Player Name text
//   the player name X position varies depending on whether or not the death timer is configured to be displayed
// CompPD.hudConfigArr["HUD_Line_Player_Name_X_Position_With_Death_Time"] = 100;
// CompPD.hudConfigArr["HUD_Line_Player_Name_X_Position_Without_Death_Time"] = 50;

//   player width must equal no more than (HUD Width) - (Player Name X Position)
// CompPD.hudConfigArr["HUD_Line_Player_Name_Width_Without_Killer_Name"] = 160;
// CompPD.hudConfigArr["HUD_Line_Player_Name_Width_With_Killer_Name"] = 310;
// CompPD.hudConfigArr["HUD_Line_Player_Name_Height"] = 20;


//	 parent HUD GUI width dependant on configuration variables
// CompPD.hudConfigArr["HUD_Width_With_Death_Time_Without_Killer_Name"] = 260;
// CompPD.hudConfigArr["HUD_Width_With_Death_Time_With_Killer_Name"] = 410;
// CompPD.hudConfigArr["HUD_Width_Without_Death_Time_Without_Killer_Name"] = 210;
// CompPD.hudConfigArr["HUD_Width_Without_Death_Time_With_Killer_Name"] = 360;


